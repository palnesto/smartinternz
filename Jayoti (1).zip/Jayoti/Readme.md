You may delete the following folder, since they are provided but not used in the project
./useless imgs
./fonts
